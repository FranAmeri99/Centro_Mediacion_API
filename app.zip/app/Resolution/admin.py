from django.contrib import admin

from Resolution.models import *
admin.site.register(Resolution)