from django.apps import AppConfig


class ResolutionConfig(AppConfig):
    name = 'Resolution'
