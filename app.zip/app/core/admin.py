from django.contrib import admin


from core.models import *

admin.site.register(Case)

admin.site.register(State)

admin.site.register(MediationPortafolio)

admin.site.register(MediationSessions)